Modify config.txt file, run skypool-node-client to start mining.
In Linux and MacOS, use `./skypool-node-client` in terminal to run mining.

config.txt description：

* address: wallet address, mining reward will send to this address automatically.
* name: mining machine name, used for skypool web page to see details for each machine.
* thread:  number of mining CPU threads. If set to the number of your threads, it means fully mining. If you want to use the computer while mining, it is recommended to set the number of CPU threads minus 1. Default is 0, 0 means CPU threads minus 1.
* percent: percentage of CPU usage, 100 is 100% full mining, ranging from 50 to 100.
* server: node address of Skypool mining servers, 'auto' for auto select and switch to avaliable server when current server crash down. Setting to follow server list means only connect to selected server.

Server List:
Shanghai-0: https://sh0.nimiq.skypool.org/
Shanghai-1: https://sh1.nimiq.skypool.org/
Hongkong: https://hk1.nimiq.skypool.org/
Europe: https://eu1.nimiq.skypool.org/
USA-1(West): https://us1.nimiq.skypool.org/
USA-2(West): https://us2.nimiq.skypool.org/
USA-3(East): https://us3.nimiq.skypool.org/
